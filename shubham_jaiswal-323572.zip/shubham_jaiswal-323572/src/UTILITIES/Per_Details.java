package UTILITIES;

public class Per_Details {
	
	public String category;
	public String string;
	public double quantity;
	public String product;
	public String total;
}
