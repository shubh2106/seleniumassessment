import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class main 
{	static functions f;
	
	public static void main(String args[]) throws IOException
	{
		
		
		f=new functions();
		int key=f.noofrows("KEYWORD");
		int sel=f.noofrows("TC_SELECTION");
		int j,x;
		for( x=1;x<sel;x++)
		{
			f.read(x,"TC_SELECTION");
			String a=f.tc_id;
			//int b=f.steps;
			//System.out.println(f.flag);
			//int count=0;
			if(f.flag.equals("Y"))
			{
				//System.out.println(f.steps);
				for( j=1;j<=key;j++) 
				{
					String id=f.read_ids(j);
					if(id.equals(a)) 
					break;
					else 
					continue;
				}
				System.out.println(j);
				check(j,x);
			}
				else
					continue;
				
	
}
}
	public static void check(int j,int i)
	{
		
		int b=f.steps;
		System.out.println(j+" "+b);
		for(int k=j;k<(j+b);k++) 
		{
			//System.out.println("here");
			f.read(k,"KEYWORD");
			String ch=f.keyword;
			System.out.println(ch);
			switch(ch) 
			{
			case "launchBrowser": f.launchBrowser(f.test_data);
			 
			 break;
			case "enter_text" : f.enter_text(f.xpath,f.test_data);
			
			break;
			case "r_sex": f.r_sex("Male");
			
			break;
			case "clickButton": f.clickButton(f.xpath);
			
			break;
			case "clickLink" :f.clickButton(f.xpath);
			
			break;
//			case "waitexp" : f.waiting(f.xpath);
//				break;
			case "logsupd" : f.logging(f.test_data);
				break;
			case "Verify"  : String a=(f.verify(f.xpath,f.test_data));
			f.write(k, "KEYWORD", a);
			f.write(i,"TC_SELECTION",a);
			
			break;
			}
	}
	}
	}
		
	
	
	